public class Node {
    Card data;
    Node next;
    public Node(Card data){
        this.data = data;
        next = null;
    }
}
